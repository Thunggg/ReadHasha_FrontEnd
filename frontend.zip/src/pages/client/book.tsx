const BookPage = () => {
    return (
        <div>
            book page
        </div>
    )
}

export default BookPage