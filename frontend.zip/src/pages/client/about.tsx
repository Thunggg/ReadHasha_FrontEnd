const AboutPage = () => {
    return (
        <div>
            about page
        </div>
    )
}

export default AboutPage