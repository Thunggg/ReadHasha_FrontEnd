const ManageBookPage = () => {
    return (
        <div>
            ManageBook Page
        </div>
    )
}

export default ManageBookPage