const DashBoardPage = () => {
    return (
        <div>
            DashBoard Page
        </div>
    )
}

export default DashBoardPage