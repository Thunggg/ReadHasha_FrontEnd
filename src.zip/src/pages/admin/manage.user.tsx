// import TableUser from "@/components/admin/user/table.user"

const ManageUserPage = () => {
    return (
        <div>
            {/* <TableUser /> */}
        </div>
    )
}

export default ManageUserPage