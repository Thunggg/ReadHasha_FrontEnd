const ManageOrderPage = () => {
    return (
        <div>
            ManageOrder Page
        </div>
    )
}

export default ManageOrderPage