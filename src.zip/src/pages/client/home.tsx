const HomePage = () => {
    return (
        <div>
            home page
        </div>
    )
}

export default HomePage